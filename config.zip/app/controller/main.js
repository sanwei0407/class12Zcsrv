'use strict';

const Controller = require('egg').Controller;

class CommonController extends Controller {

  // 微信用户登录
  async wxlogin() {

  }


  // 添加商品
  async addGoods() {

  }

}

module.exports = CommonController;
